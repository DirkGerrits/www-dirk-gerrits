#
# Regular cron jobs for the xournal package
#
0 4	* * *	root	xournal_maintenance
