?package(xournal):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="xournal" command="/usr/bin/xournal"
