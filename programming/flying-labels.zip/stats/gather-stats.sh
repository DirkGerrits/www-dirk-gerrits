#!/bin/sh

runs=100
for trimming in none 10; do 
  if [ "$trimming" = "none" ]
  then directory="untrimmed-stats"
  else directory="trimmed-stats"
  fi
  for timestep in 0 0.125 0.25 0.5 1 2 3 4 5 10 15 30 61; do
    filename="$directory/stats-$timestep-%r.csv"
    if [ "$timestep" = "0" ]
    then method="AlwaysRelabel"; timestep=1
    else method="SlowestInterpolation"
    fi
    echo $filename

    if [ "$trimming" = "none" ]
    then ./flying-labels eindhoven3.ipe $method --runs $runs --timestep $timestep --output $filename
    else ./flying-labels eindhoven3.ipe $method --runs $runs --timestep $timestep --trimming 10 --output $filename
    fi
  done
done