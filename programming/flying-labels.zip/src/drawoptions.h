#ifndef DRAWOPTIONS_H
#define DRAWOPTIONS_H

#include <array>
enum DrawOption
{
    DrawLabelModel, DrawLabelBBox, DrawLabelCenter, DrawLabelText,
    DrawVertices, DrawEdges, DrawRoutes, DrawMovingPoints,
    ColorLabelsByFreeArea,

    NumberOfDrawOptions
};
typedef std::array<bool, NumberOfDrawOptions> DrawOptions;

#endif // DRAWOPTIONS_H
