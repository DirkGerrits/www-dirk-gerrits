#ifndef TIMESLIDER_H
#define TIMESLIDER_H

#include <QSlider>

class TimeSlider : public QSlider
{
    Q_OBJECT
public:
    explicit TimeSlider(QWidget* parent = nullptr);
    
    // To ensure the tick marks on the slider match up with the GraphingArea,
    // one must narrow the latter horizontally by these amounts.
    int leftOffset() const;
    int rightOffset() const { return leftOffset(); }
};

#endif // TIMESLIDER_H
