#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <QtGlobal>

const qreal vertexRadius = 3;

const qreal vertexProximityRadius = 7;
const qreal vertexProximityRadiusSquared = vertexProximityRadius*vertexProximityRadius;

const qreal arrowSpacing = 20;
const qreal arrowHeadLength = 5;
const qreal arrowHeadWidth = 5;

const qreal secondsPerTick = 40.0/1024;
const int millisecondsPerTick = (int)(secondsPerTick*1000);

inline qreal secondsToTicks(qreal seconds) { return seconds / secondsPerTick; }
inline qreal ticksToSeconds(int ticks) { return ticks * secondsPerTick; }

#endif // CONSTANTS_H

