#ifndef INSTANCEOBSERVER_H
#define INSTANCEOBSERVER_H

class ProblemInstance;
class InstanceObserver
{
public:
    InstanceObserver() {}
    virtual ~InstanceObserver() = 0;

    virtual void instanceDurationChanged() {}
    virtual void instanceHadRouteAdded() {}
    virtual void instanceAirplaneScheduleChanged() {}
    virtual void instanceLabelModelChanged() {}
    virtual void instanceWasReplaced(ProblemInstance&) { }
    virtual void instanceIsBeingDestroyed() {}
};

inline InstanceObserver::~InstanceObserver() {}

#endif // INSTANCEOBSERVER_H
