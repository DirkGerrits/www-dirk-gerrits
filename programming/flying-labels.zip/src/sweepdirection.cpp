#include "sweepdirection.h"
#include "labeledpoint.h"
#include "labelmodel.h"
#include "geomutils.h"

namespace {

void turn(LabeledPoint& p)
{
    turnPoint90CW(p.position());
    turnPoint90CW(p.direction());
    turnPoint90CW(p.labelCenter());
    p.labelCandidates().turnClockwise();
}

void unturn(LabeledPoint& p)
{
    turnPoint90CCW(p.position());
    turnPoint90CCW(p.direction());
    turnPoint90CCW(p.labelCenter());
    p.labelCandidates().turnCounterClockwise();
}

void mirror(LabeledPoint& p)
{
    mirrorPointH(p.position());
    mirrorPointH(p.direction());
    mirrorPointH(p.labelCenter());
    p.labelCandidates().mirror();
}

} // unnamed namespace

QPointF& SweepDirection::transform(QPointF& p) const
{
    if (_isTurned) turnPoint90CW(p);
    if (_isMirrored) mirrorPointH(p);
    return p;
}
QPointF& SweepDirection::untransform(QPointF& p) const
{
    if (_isMirrored) mirrorPointH(p);
    if (_isTurned) turnPoint90CCW(p);
    return p;
}

LabeledPoint& SweepDirection::transform(LabeledPoint& p) const
{
    if (_isTurned) turn(p);
    if (_isMirrored) mirror(p);
    return p;
}

LabeledPoint& SweepDirection::untransform(LabeledPoint& p) const
{
    if (_isMirrored) mirror(p);
    if (_isTurned) unturn(p);
    return p;
}
