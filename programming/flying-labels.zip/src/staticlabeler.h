#ifndef STATICLABELER_H
#define STATICLABELER_H

#include "sweepdirection.h"

class StaticLabeling;

class StaticLabeler
{
protected:
    StaticLabeler();
public:
    virtual ~StaticLabeler();

    StaticLabeler(StaticLabeler const&) = delete;
    StaticLabeler& operator=(StaticLabeler const&) = delete;
public:
    virtual void computeLabeling(StaticLabeling& emptyLabeling) const = 0;
};

class GreedySweepLabeler : public StaticLabeler
{
public:
    explicit GreedySweepLabeler(SweepDirection dir);
    void computeLabeling(StaticLabeling& labeling) const;

private:
    SweepDirection _dir;
};

class FourGreedySweepsLabeler : public StaticLabeler
{
public:
    FourGreedySweepsLabeler();
    void computeLabeling(StaticLabeling& labeling) const;
};


#endif // STATICLABELER_H
