#ifndef COMMANDLINE_H
#define COMMANDLINE_H

#include <stdexcept>

class CommandLineError : public std::runtime_error
{
public:
    CommandLineError(std::string&& msg)
        : std::runtime_error(std::move(msg))
    {}
    ~CommandLineError() throw() {}
};

bool performWorkFromCommandline(int argc, char* argv[]);

#endif // COMMANDLINE_H
