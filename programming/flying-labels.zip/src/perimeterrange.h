#ifndef PERIMETERRANGE_H
#define PERIMETERRANGE_H

#include <QtGlobal>
#include <utility>

typedef std::pair<qreal, qreal> PerimeterRange;

// shift `range` by multiples of `labelPerimeter` until it contains `value`
void shiftPerimeterRangeOntoValue(PerimeterRange& range, qreal value, qreal labelPerimeter);

// shift `value` by multiples of `labelPerimeter` until `range` contains it
void shiftValueOntoPerimeterRange(qreal& value, PerimeterRange const& range, qreal labelPerimeter);

// shift `range2` by multiples of `labelPerimeter` until `range1` and `range2` differ
// in first endpoint by less than `labelPerimeter`
void alignPerimeterRanges(PerimeterRange const& range1, PerimeterRange& range2, qreal labelPerimeter);

PerimeterRange intersectRanges(PerimeterRange const& range1, PerimeterRange const& range2);

bool inPerimeterRange(qreal value, PerimeterRange const& range);

bool perimeterRangesOverlap(PerimeterRange const& range1, PerimeterRange const& range2);

class LabelModel;
class Airplane;
class Portal {
public:
    Portal(qreal time, PerimeterRange range) : _range(range), _time(time) {}
    Portal(qreal time, Airplane const& airplane, LabelModel const& labelModel);
    PerimeterRange const& range() const { return _range; }
    qreal time() const { return _time; }
private:
    PerimeterRange _range;
    qreal _time;
};

#endif // PERIMETERRANGE_H
