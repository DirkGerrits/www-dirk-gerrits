#ifndef SLOWESTINTERPOLATION_H
#define SLOWESTINTERPOLATION_H

#include "dynamiclabeling.h"
#include "airplane.h"
#include "labeltrajectory.h"
#include <unordered_map>
#include <vector>

class StaticLabeling;

class SlowestInterpolation : public DynamicLabeling
{
public:
    explicit SlowestInterpolation(ProblemInstance const& problemInstance, qreal timestep = 5, qreal trimming = NO_TRIMMING);

protected:
    void invalidate();
    void updateDuration();
    StaticLabeling computeLabelingAtTime(qreal time);

private:
    int chunkForTime(qreal time) const { return (int)(time / timestep()); }
    int numberOfChunks() const;

    void computeChunkTrajectories(qreal time);
    LabelTrajectory computeTrajectoryInChunk(
            Airplane const& airplane, StaticLabeling const& labeling1, StaticLabeling const& labeling2);

private:
    // NOTE: trying to store an `unordered_map` into a `vector` directly (without the following workaround)
    // results in compilation errors in GCC 4.7.2 and Clang 3.1.  Both compilers complain that `pair<AirplaneId,
    // LabelTrajectory>` has no copy constructor (because `LabelTrajectory` is move only).  While this behavior
    // is allowed by the C++11 standard, it's hardly ideal, and newer versions of both compilers fix it.
    // More info: https://groups.google.com/a/isocpp.org/d/topic/std-discussion/b8WhfXMpQpg/discussion
    class ChunkTrajectories : public std::unordered_map<AirplaneID, LabelTrajectory>
    {
    public:
        ChunkTrajectories() {}
        ChunkTrajectories(ChunkTrajectories const&) = delete;
        ChunkTrajectories& operator=(ChunkTrajectories const&) = delete;
        ChunkTrajectories(ChunkTrajectories&&) = default;
        ChunkTrajectories& operator=(ChunkTrajectories&&) = default;
    };
    std::vector<ChunkTrajectories> _labelTrajectories;
};

#endif // SLOWESTINTERPOLATION_H
