#ifndef AIRPLANE_H
#define AIRPLANE_H

#include <QPointF>

class AirplanePool;
class AirplaneRoute;
typedef unsigned int AirplaneID;

class Airplane
{
public:
    Airplane(AirplanePool& pool, AirplaneRoute const& route, qreal timeOffset, AirplaneID id, AirplaneID relativeId);
    ~Airplane();

    Airplane(Airplane const&) = delete;
    Airplane& operator=(Airplane const&) = delete;

    AirplaneID id() const;
    AirplaneID relativeId() const;
    AirplaneRoute const& route() const;
    QPointF positionAtTime(qreal time) const;
    QPointF directionAtTime(qreal time) const;
    qreal timeOnRoute(qreal time) const;

    void setId(AirplaneID id);
    void setTimeOfBirth(qreal t);

    qreal timeOfBirth() const;
    qreal timeOfDeath() const;    
    bool isAliveAt(qreal time) const;
    bool isAliveBetween(qreal time1, qreal time2) const;
    QString labelText() const;

private:
    qreal _timeOffset;
    mutable AirplanePool* _pool;
    AirplaneRoute const* _route;
    AirplaneID _uniqueID;
    AirplaneID _relativeID;
};

#endif // AIRPLANE_H
