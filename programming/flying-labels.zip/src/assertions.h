#ifndef ASSERTIONS_H
#define ASSERTIONS_H

#include <cassert>

#ifdef NDEBUG

#  define assertEqual(x, y) (static_cast<void>(0))
#  define assertMonotonicInX(v) (static_cast<void>(0))
#  define assertSubset(x, y) (static_cast<void>(0))
#  define assertSubsetAfterAlignment(x, y, z) (static_cast<void>(0))

#else

#include <vector>
#include <QtGlobal>
#include "perimeterrange.h"
class QPointF;
class LabelCandidateSegment;
class LabelCandidates;
class LabelModel;

void assertEqual(qreal x1, qreal x2);
void assertEqual(QPointF const& p1, QPointF const& p2);
void assertEqual(PerimeterRange const& range1, PerimeterRange const& range2);
void assertEqual(LabelCandidateSegment const& segment1, LabelCandidateSegment const& segment2);
void assertEqual(LabelCandidates const& candidates1, LabelCandidates const& candidates2);

void assertSubset(PerimeterRange const& subrange, PerimeterRange const& range);
void assertSubsetAfterAlignment(PerimeterRange const& subrange, PerimeterRange range, qreal labelPerimeter);
void assertSubsetAfterAlignment(PerimeterRange const& subrange, PerimeterRange range, LabelModel const& labelModel);

void assertSubset(LabelCandidateSegment const& subsegment, LabelCandidateSegment const& segment);
void assertSubset(LabelCandidates const& subcandidates, LabelCandidates const& candidates);

void assertMonotonicInX(std::vector<QPointF> const& vertices);

#endif // NDEBUG

#endif // ASSERTIONS_H
