#include <QtGui/QApplication>
#include <iostream>
#include "flyinglabels.h"
#include "commandline.h"

// NOTE: this function exists mainly as a venue to place a breakpoint for when
// something goes wrong that doesn't show up until reaching Qt code.
void qtErrorHandler(QtMsgType type, char const* msg)
{
    switch (type) {
    case QtDebugMsg:
        std::cerr << "Debug: " << msg << std::endl;
        break;
    case QtWarningMsg:
        std::cerr << "Warning: " << msg << std::endl;
        break;
    case QtCriticalMsg:
        std::cerr << "Critical: " << msg << std::endl;
        break;
    case QtFatalMsg:
        std::cerr << "Fatal: " << msg << std::endl;
        abort();
    }
}

int main(int argc, char* argv[])
{
    qInstallMsgHandler(qtErrorHandler);
    QApplication application(argc, argv);
    FlyingLabels window; // without a main window we can't compute the label bounding box from a QFont instance

    if (performWorkFromCommandline(argc, argv)) {
        return 0;
    } else {
        window.show();
        return application.exec();
    }
}
