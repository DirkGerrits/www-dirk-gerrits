#ifndef PORTALS_H
#define PORTALS_H

#include <vector>
#include "perimeterrange.h"
#include "labeltrajectory.h"

class Airplane;
class LabelModel;

class Portals
{
public:
    Portals(Airplane const& airplane, LabelModel const& labelModel, qreal time1, qreal time2);

    Portals(Portals const&) = delete;
    Portals& operator=(Portals const&) = delete;

    Portals(Portals&&) = default;
    Portals& operator=(Portals&&) = default;

    LabelTrajectory shortestPointToPointPath(qreal label1, qreal label2) const;
    LabelTrajectory shortestPointToEdgePath(qreal label1) const;
    LabelTrajectory shortestEdgeToPointPath(qreal label2) const;
    LabelTrajectory shortestEdgeToEdgePath() const;

    Portal const& portal1() const { return _portals.front(); }
    Portal const& portal2() const { return _portals.back(); }

    qreal time1() const { return portal1().time(); }
    qreal time2() const { return portal2().time(); }

    PerimeterRange const& range1() const { return portal1().range(); }
    PerimeterRange const& range2() const { return portal2().range(); }

    PerimeterRange trimmedRange1(qreal trimAmount) const;
    PerimeterRange trimmedRange2(qreal trimAmount) const;

    void printForIpe() const;
private:
    void computePortals(Airplane const& airplane, LabelModel const& labelModel, qreal time1, qreal time2);

    void printPassage(Portal const& p1, Portal const& p2) const;

private:
    std::vector<Portal> _portals;
    int _labelPerimeter;
};

#endif // PORTALS_H
