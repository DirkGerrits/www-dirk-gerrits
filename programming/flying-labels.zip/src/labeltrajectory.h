#ifndef LABELTRAJECTORY_H
#define LABELTRAJECTORY_H

#include <QPointF>
#include <vector>

enum TrajectoryType
{
    PointToPoint, PointToEdge, EdgeToPoint, EdgeToEdge
};

class LabelTrajectory
{
public:
    LabelTrajectory(std::vector<QPointF>&& vertices, TrajectoryType type);

    qreal parameterValueAtTime(qreal time) const;

    LabelTrajectory(LabelTrajectory const&) = delete;
    LabelTrajectory& operator=(LabelTrajectory const&) = delete;

    LabelTrajectory(LabelTrajectory&&) = default;
    LabelTrajectory& operator=(LabelTrajectory&&) = default;

    void printForIpe() const;

private:
    std::vector<QPointF> _vertices; // x = time, y = perimeter value
    TrajectoryType _type; // for debugging purposes
};

#endif // LABELTRAJECTORY_H
