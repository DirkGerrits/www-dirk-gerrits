#ifndef SWEEPDIRECTION_H
#define SWEEPDIRECTION_H

#include <QPointF>
class LabeledPoint;

class SweepDirection {
    SweepDirection(bool isTurned, bool isMirrored)
        : _isTurned(isTurned), _isMirrored(isMirrored)
    {}
public:
    static SweepDirection LeftToRight() { return SweepDirection(false, false); }
    static SweepDirection RightToLeft() { return SweepDirection(false, true); }
    static SweepDirection TopToBottom() { return SweepDirection(true,  true); }
    static SweepDirection BottomToTop() { return SweepDirection(true,  false); }

    QPointF& transform(QPointF& p) const;
    QPointF& untransform(QPointF& p) const;
    LabeledPoint& transform(LabeledPoint& p) const;
    LabeledPoint& untransform(LabeledPoint& p) const;

private:
    bool _isTurned, _isMirrored;
};

#endif // SWEEPDIRECTION_H
