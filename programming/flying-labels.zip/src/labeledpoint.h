#ifndef LABELEDPOINT_H
#define LABELEDPOINT_H

#include <QPointF>
#include "perimeterrange.h"
#include "labelcandidates.h"
class LabelModel;
class Airplane;

class LabeledPoint {
public:
    LabeledPoint(Airplane const& airplane, LabelModel const& labelModel, qreal time);

    LabeledPoint(LabeledPoint const&) = default;
    LabeledPoint& operator=(LabeledPoint const&) = default;

    Airplane const& airplane() const { return *_airplane; }
    qreal time() const { return _time; }
    QPointF const& position() const { return _position; }
    QPointF& position() { return _position; }
    QPointF const& direction() const { return _direction; }
    QPointF& direction() { return _direction; }

    LabelCandidates const& labelCandidates() const { return _labelCandidates; }
    LabelCandidates& labelCandidates() { return _labelCandidates; }
    PerimeterRange const& perimeterRange() const { return _perimeterRange; }
    PerimeterRange& perimeterRange() { return _perimeterRange; }

    QPointF const& labelCenter() const { return _labelCenter; }
    QPointF& labelCenter() { return _labelCenter; }
    qreal labelPerimeterValue() const { return _labelPerimeterValue; }

    bool isLabelFullyFree() const { return _labelFreeness >= (1.0 - 1e-5); }
    qreal& labelFreeness() { return _labelFreeness; }
    qreal labelFreeness() const { return _labelFreeness; }

    void setLabel(QPointF const& labelCenter, LabelModel const& labelModel);
    void setLabel(qreal perimeterValue, LabelModel const& labelModel);

    void setLabelCandidates(PerimeterRange const& range, LabelModel const& labelModel);

private: // TODO: the sizeof(..) this class is pretty big (264 bytes); perhaps we can slim it down a bit?
    LabelCandidates _labelCandidates;
    PerimeterRange _perimeterRange;
    QPointF _position, _direction;
    QPointF _labelCenter;
    qreal _labelPerimeterValue;
    qreal _labelFreeness;
    qreal _time;
    Airplane const* _airplane;
};

#endif // LABELEDPOINT_H
