#include "airplane.h"
#include "airplanepool.h"
#include "airplaneroute.h"

Airplane::Airplane(AirplanePool& pool, AirplaneRoute const& route, qreal timeOffset, AirplaneID id, AirplaneID relativeId)
    : _timeOffset(timeOffset), _pool(&pool), _route(&route), _uniqueID(id), _relativeID(relativeId)
{
}

Airplane::~Airplane()
{
}

AirplaneID Airplane::id() const
{
    _pool->ensureProperAirplaneIDs();
    return _uniqueID;
}
AirplaneID Airplane::relativeId() const
{
    return _relativeID;
}

AirplaneRoute const& Airplane::route() const
{
    return *_route;
}

QPointF Airplane::positionAtTime(qreal time) const
{
    return _route->positionAtTime( timeOnRoute(time) );
}

QPointF Airplane::directionAtTime(qreal time) const
{
    return _route->directionAtTime( timeOnRoute(time) );
}

qreal Airplane::timeOnRoute(qreal time) const
{
    return time - _timeOffset;
}

void Airplane::setId(AirplaneID id)
{
    _uniqueID = id;
}

void Airplane::setTimeOfBirth(qreal t)
{
    _timeOffset = t;
}

qreal Airplane::timeOfBirth() const
{
    return _timeOffset;
}
qreal Airplane::timeOfDeath() const
{
    return _route->timeLength() + _timeOffset;
}

bool Airplane::isAliveAt(qreal time) const
{
    return timeOfBirth() <= time && time < timeOfDeath();
}
bool Airplane::isAliveBetween(qreal time1, qreal time2) const
{
    return timeOfDeath() > time1 && timeOfBirth() <= time2;
}

QString Airplane::labelText() const {
    return _route->labelText(id(), relativeId());
}
