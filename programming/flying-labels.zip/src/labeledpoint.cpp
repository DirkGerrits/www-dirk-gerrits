#include "labeledpoint.h"
#include "labelmodel.h"
#include "airplane.h"
#include "assertions.h"

LabeledPoint::LabeledPoint(Airplane const& airplane, LabelModel const& labelModel, qreal time)
    : _labelCandidates( labelModel.labelCandidates(airplane, time) ),
      _perimeterRange( labelModel.perimeterRange(airplane, time) ),
      _position( airplane.positionAtTime(time)),
      _direction( airplane.directionAtTime(time) ),
      _labelCenter(), _labelFreeness(0.0), _time(time),
      _airplane(&airplane)
{
}

void LabeledPoint::setLabel(QPointF const& labelCenter, LabelModel const& labelModel)
{
    _labelCenter = labelCenter;
    _labelPerimeterValue = labelModel.labelToPerimeterValue(_position, labelCenter);
    _labelFreeness = 0.0;
}

void LabeledPoint::setLabel(qreal perimeterValue, LabelModel const& labelModel)
{
    _labelCenter = labelModel.labelPosition(_position, perimeterValue);
    _labelPerimeterValue = perimeterValue;
    _labelFreeness = 0.0;
}

void LabeledPoint::setLabelCandidates(PerimeterRange const& range, LabelModel const& labelModel)
{
    assertSubsetAfterAlignment(range, _perimeterRange, labelModel);
    assertSubset(labelModel.labelCandidates(_position, range), _labelCandidates);

    _labelCandidates = labelModel.labelCandidates(_position, range);
    _perimeterRange = range;
}
