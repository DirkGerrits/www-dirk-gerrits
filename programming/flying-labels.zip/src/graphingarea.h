#ifndef GRAPHINGAREA_H
#define GRAPHINGAREA_H

#include <QWidget>
#include <QImage>

class GraphingArea : public QWidget
{
    Q_OBJECT
public:
    explicit GraphingArea(QWidget* parent = nullptr);

    GraphingArea(GraphingArea const&) = delete;
    GraphingArea& operator=(GraphingArea const&) = delete;

    void clear();
    void drawFreeAndTotalBar(qreal free, qreal total, std::size_t bar, std::size_t numBars);
    void drawSpeedBar(qreal minSpeed, qreal avgSpeed, qreal maxSpeed, qreal speedLimit,
                      std::size_t bar, std::size_t numBars);

    void timelineOffsets(int leftOffset, int rightOffset) { _leftOffset = leftOffset; _rightOffset = rightOffset; }

private:
    void drawBar(qreal value, qreal maxValue, std::size_t bar, std::size_t numBars,
                 Qt::GlobalColor color);
    void ensureImageIsLargeEnough(int minWidth, int minHeight);
    qreal pixelToBar(qreal px) const;
    qreal barToPixel(qreal bar) const;

    int canvasWidth() const;
    int graphWidth() const;

protected:
    void paintEvent(QPaintEvent* event);
    void resizeEvent(QResizeEvent* event);

private:
    QImage _image;
    int _numBars;
    int _leftOffset, _rightOffset; // the GraphingArea widget is wider by this amount than the actual time line
};

#endif // GRAPHINGAREA_H
