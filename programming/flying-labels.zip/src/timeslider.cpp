#include "timeslider.h"
#include <QPainter>
#include <QStyleOptionSlider>
#include <QApplication>

TimeSlider::TimeSlider(QWidget *parent) :
    QSlider(parent)
{
}

int TimeSlider::leftOffset() const
{
    // This was gleaned from qwindowsxpstyle.cpp and qgtkstyle.cpp.
    // Hopefully it also looks good on other platforms.
    QStyleOptionSlider option;
    initStyleOption(&option);
    QStyle* style = QApplication::style();
    int len = style->pixelMetric(QStyle::PM_SliderLength, &option, this);
    return len/2;
}
